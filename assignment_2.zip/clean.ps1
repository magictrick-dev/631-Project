rm -Force -Recurse ./build
rm -Force -Recurse ./bin
