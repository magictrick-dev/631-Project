./bin/Debug/j5.exe ./rdviews/s25.rd
