cmake -B ./build
cmake --build ./build
