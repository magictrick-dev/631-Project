#ifndef J5_CORE_DEFINITIONS_H
#define J5_CORE_DEFINITIONS_H
#include <cassert>

#endif
