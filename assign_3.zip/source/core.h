#ifndef J5_CORE_H
#define J5_CORE_H
#include <core/primitives.h>
#include <core/linear.h>
#include <core/definitions.h>

#endif
