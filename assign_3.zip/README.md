# J5 Graphics Engine

A graphics engine built entirely from scratch, pixel-by-pixel.

### Documentation

In order to build the project, run `cmake -B ./build`, and to compile it,
run `cmake --build ./build`. Needs MSVC to work. (Thanks Microsoft, very cool!)

Invoke with `j5.exe [rdfile]`.

Example: `./bin/Debug/j5.exe rdviews/s03.rd` will run the line example.
