./bin/Debug/j5.exe ./rdviews/spheres.rd
